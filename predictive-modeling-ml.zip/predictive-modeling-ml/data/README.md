# Data

This project does **not** commit a raw data file to the repository.

The dataset — the **Breast Cancer Wisconsin (Diagnostic) Data Set** — is loaded
directly from scikit-learn at runtime:

```python
from sklearn.datasets import load_breast_cancer
data = load_breast_cancer(as_frame=True)
df = data.frame
```

This keeps the repository small, avoids redistributing third-party data, and
makes the project fully reproducible offline (no network access or manual
download step is needed).

## Source

- Origin: UCI Machine Learning Repository — Breast Cancer Wisconsin (Diagnostic) Data Set
- Distributed via: `sklearn.datasets.load_breast_cancer`
- Samples: 569
- Features: 30 numeric measurements per sample (mean, standard error, and
  "worst" value of 10 base measurements of cell nuclei from a digitized
  biopsy image)
- Target: binary diagnosis — malignant (0) or benign (1)

See the main [README.md](../README.md) for the full dataset documentation,
EDA, and modeling workflow.
